@REM Executes a command within the Emscripten SDK environment
@CALL %EMSDK%\emsdk_env.bat > NUL
@CALL %*
